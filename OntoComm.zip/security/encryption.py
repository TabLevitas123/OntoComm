
from cryptography.fernet import Fernet
import os
import logging

class EncryptionManager:
    def __init__(self):
        key = os.getenv('ENCRYPTION_KEY')
        if not key:
            key = Fernet.generate_key()
            # Securely store the generated key
        self.fernet = Fernet(key)
        self.logger = logging.getLogger(self.__class__.__name__)

    def encrypt_data(self, data):
        self.logger.info("Encrypting data.")
        encrypted = self.fernet.encrypt(data.encode())
        return encrypted

    def decrypt_data(self, encrypted_data):
        self.logger.info("Decrypting data.")
        decrypted = self.fernet.decrypt(encrypted_data).decode()
        return decrypted
