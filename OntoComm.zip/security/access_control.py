
import logging

class AccessControl:
    def __init__(self):
        self.roles = {}
        self.logger = logging.getLogger(self.__class__.__name__)

    def define_role(self, role_name, permissions):
        self.roles[role_name] = permissions
        self.logger.info(f"Defined role: {role_name} with permissions: {permissions}")

    def check_permission(self, role_name, permission):
        self.logger.info(f"Checking permission: {permission} for role: {role_name}")
        return permission in self.roles.get(role_name, [])
