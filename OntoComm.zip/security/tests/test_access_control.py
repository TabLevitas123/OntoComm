
import unittest
from security.access_control import AccessControl

class TestAccessControl(unittest.TestCase):
    def setUp(self):
        self.access_control = AccessControl()
        self.access_control.define_role('admin', ['read', 'write', 'delete'])
        self.access_control.define_role('user', ['read'])

    def test_permission_admin(self):
        self.assertTrue(self.access_control.check_permission('admin', 'delete'))

    def test_permission_user(self):
        self.assertFalse(self.access_control.check_permission('user', 'delete'))
        self.assertTrue(self.access_control.check_permission('user', 'read'))

    def test_permission_unknown_role(self):
        self.assertFalse(self.access_control.check_permission('guest', 'read'))

if __name__ == '__main__':
    unittest.main()
