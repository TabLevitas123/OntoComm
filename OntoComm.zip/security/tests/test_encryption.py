
import unittest
from security.encryption import EncryptionManager

class TestEncryptionManager(unittest.TestCase):
    def setUp(self):
        self.encryption_manager = EncryptionManager()

    def test_encrypt_decrypt(self):
        original = "Sensitive Data"
        encrypted = self.encryption_manager.encrypt_data(original)
        decrypted = self.encryption_manager.decrypt_data(encrypted)
        self.assertEqual(original, decrypted)

if __name__ == '__main__':
    unittest.main()
