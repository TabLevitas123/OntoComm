
import json

def serialize_data(data):
    return json.dumps(data)
