
from .storage import StorageManager
import logging

class RecallManager:
    def __init__(self):
        self.storage_manager = StorageManager()
        self.logger = logging.getLogger(self.__class__.__name__)

    def recall_context(self, key):
        self.logger.info(f"Recalling context for key: {key}")
        data = self.storage_manager.retrieve_data(key)
        if data:
            return data
        else:
            self.logger.error(f"Context not found for key: {key}")
            return None
