
from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import logging
import json
from .utils import serialize_data
from .config import GeminiConfig

Base = declarative_base()
engine = create_engine(GeminiConfig.DATABASE_URI)
Session = sessionmaker(bind=engine)
session = Session()

class ContextData(Base):
    __tablename__ = 'context_data'
    id = Column(Integer, primary_key=True)
    key = Column(String, unique=True, nullable=False)
    value = Column(Text, nullable=False)

Base.metadata.create_all(engine)

class StorageManager:
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def store_data(self, key, data):
        serialized_data = serialize_data(data)
        context_entry = ContextData(key=key, value=serialized_data)
        session.add(context_entry)
        session.commit()
        self.logger.info(f"Data stored with key: {key}")

    def retrieve_data(self, key):
        context_entry = session.query(ContextData).filter_by(key=key).first()
        if context_entry:
            self.logger.info(f"Data retrieved with key: {key}")
            return json.loads(context_entry.value)
        else:
            self.logger.warning(f"No data found for key: {key}")
            return None
