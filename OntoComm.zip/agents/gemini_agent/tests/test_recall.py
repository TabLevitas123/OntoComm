
import unittest
from agents.gemini_agent.recall import RecallManager

class TestRecallManager(unittest.TestCase):
    def setUp(self):
        self.recall_manager = RecallManager()

    def test_recall_existing_context(self):
        test_key = 'test_recall_key'
        test_data = {'recall': 'data'}
        self.recall_manager.storage_manager.store_data(test_key, test_data)
        recalled_data = self.recall_manager.recall_context(test_key)
        self.assertEqual(test_data, recalled_data)

    def test_recall_nonexistent_context(self):
        recalled_data = self.recall_manager.recall_context('nonexistent_recall_key')
        self.assertIsNone(recalled_data)

if __name__ == '__main__':
    unittest.main()
