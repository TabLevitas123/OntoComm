
import unittest
from agents.gemini_agent.storage import StorageManager

class TestStorageManager(unittest.TestCase):
    def setUp(self):
        self.storage = StorageManager()

    def test_store_and_retrieve_data(self):
        test_key = 'test_key'
        test_data = {'example': 'data'}
        self.storage.store_data(test_key, test_data)
        retrieved_data = self.storage.retrieve_data(test_key)
        self.assertEqual(test_data, retrieved_data)

    def test_retrieve_nonexistent_data(self):
        retrieved_data = self.storage.retrieve_data('nonexistent_key')
        self.assertIsNone(retrieved_data)

if __name__ == '__main__':
    unittest.main()
