
import os
import logging
from dotenv import load_dotenv

load_dotenv()

class GeminiConfig:
    API_KEY = os.getenv('GEMINI_API_KEY')
    DATABASE_URI = os.getenv('GEMINI_DATABASE_URI', 'sqlite:///gemini_repository.db')
    CONTEXT_WINDOW_SIZE = int(os.getenv('GEMINI_CONTEXT_WINDOW_SIZE', 2000000))
